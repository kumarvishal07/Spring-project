package com.mindtree.vishal;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;

import java.util.Collection;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.test.JerseyTest;
import org.glassfish.jersey.test.TestProperties;
import org.junit.Test;

import com.mindtree.vishal.Model.Employee;
import com.mindtree.vishal.Resourse.EmployeeResourse;

 

public class TestResourse extends JerseyTest {

 @Override
 public Application configure() {
  enable(TestProperties.LOG_TRAFFIC);
  enable(TestProperties.DUMP_ENTITY);
  return new ResourceConfig(EmployeeResourse.class);
 }

 @Test
 public void testFetchAll() {
	 Collection<Employee> responseMsg = target("EmpMgt/getAllEmpDetails").request()
				.get(new GenericType<Collection<Employee>>() {
				});
	  assertEquals(false,responseMsg.isEmpty());
	  
  
 }
 @Test
 public void testDelete() {
  Response output = target("/EmpMgt/deleteEmp/14").request().delete();
  assertEquals("Should return status 200", 200, output.getStatus());
 }
 @Test
 public void testGetById() {
Response  output =  target("/EmpMgt/getByEmpId/15").request().get();
  assertEquals(200, output.getStatus());
  
 }

 @Test
 public void testAdd() {
	 Employee user = new Employee();
  Response output = target("/EmpMgt/addEmp").request().post(Entity.entity(user, MediaType.APPLICATION_JSON));
  assertEquals(200,output.getStatus());
  
 }
 @Test
 public void testCheckLogin() {
  Employee user = new Employee();
  user.setUserName("vishal");
  user.setUserName("1234");
  Response output = target("/EmpMgt/checkLogin").request().post(Entity.entity(user, MediaType.APPLICATION_JSON));
  assertEquals(200,output.getStatus());
  
 
 
   
  
 }


 
}