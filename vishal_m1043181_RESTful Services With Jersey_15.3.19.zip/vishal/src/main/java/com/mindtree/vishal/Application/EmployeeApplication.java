 package com.mindtree.vishal.Application;

 


import java.util.HashMap;

import javax.ws.rs.core.MediaType;

import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.server.filter.HttpMethodOverrideFilter;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.mindtree.vishal.Dao.EmployeeDao;

public class EmployeeApplication  extends ResourceConfig{
	public EmployeeApplication(final EmployeeDao dao)
	{
		
		JacksonJsonProvider json=new JacksonJsonProvider().configure(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS, false).configure(SerializationFeature.INDENT_OUTPUT, true);
		//JacksonXMLProvider xml=new JacksonXMLProvider().configure(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS, false).configure(SerializationFeature.INDENT_OUTPUT, true);
		packages("com.mindtree");
		register(new AbstractBinder() {
			protected void configure() {
				bind(dao).to(EmployeeDao.class);
			}
		});
		HashMap<String, MediaType> mappings=new HashMap<String,MediaType>();
		mappings.put("xml",MediaType.APPLICATION_XML_TYPE);
		mappings.put("json",MediaType.APPLICATION_JSON_TYPE);
		register(json);
		//register(xml);
		property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE,true);
		register(HttpMethodOverrideFilter.class);
		
	}

}
 