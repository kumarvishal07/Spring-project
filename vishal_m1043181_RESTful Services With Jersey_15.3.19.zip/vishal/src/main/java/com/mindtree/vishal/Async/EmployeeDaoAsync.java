package com.mindtree.vishal.Async;

import java.util.Collection;
import java.util.concurrent.Callable;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.mindtree.vishal.Dao.EmployeeDao;
import com.mindtree.vishal.Model.Employee;

public class EmployeeDaoAsync {

	EmployeeDao employeedao = new EmployeeDao();
	ListeningExecutorService service;

	public ListenableFuture<Employee> addEmpAsync(final Employee employee) {
		ListenableFuture<Employee> future = service.submit(new Callable<Employee>() {
			public Employee call() throws Exception {
				return employeedao.addEmp(employee);
			}
		});
		return future;
	}

	public ListenableFuture<Employee> getByEmpIdAsync(final String empId) {
		ListenableFuture<Employee> future = service.submit(new Callable<Employee>() {
			public Employee call() throws Exception {
				return (Employee) employeedao.getByEmpId(empId);
			}
		});
		return future;
	}

	public ListenableFuture<Employee> getAllEmpDetails() {
		System.out.println("getAllEmpDetailsdaosyn");
		ListenableFuture<Employee> future = service.submit(new Callable<Employee>() {
			public Employee call() throws Exception {
				return (Employee) employeedao.getAllEmpDetails();
			}
		});
		return future;
	}

	public ListenableFuture<Boolean> deleteEmpAsync(final String empId) {
		ListenableFuture<Boolean> future = service.submit(new Callable<Boolean>() {
			public Boolean call() throws Exception {
				return employeedao.deleteEmp(empId);
			}
		});
		return future;
	}

	public ListenableFuture<String> checkLogin(final Employee employee) {
		ListenableFuture<String> future = service.submit(new Callable<String>() {
			public String call() throws Exception {
				return employeedao.checkLogin(employee);
			}
		});
		return future;
	}

}
