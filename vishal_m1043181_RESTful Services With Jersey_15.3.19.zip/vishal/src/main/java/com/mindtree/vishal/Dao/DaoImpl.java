package com.mindtree.vishal.Dao;

import java.util.Collection;

import com.mindtree.vishal.Model.Employee;

public interface DaoImpl {

	public Collection<Employee> getAllEmpDetails();

	public Employee addEmp(Employee employee);

	public Boolean deleteEmp(String empId);

	public Collection<Employee> getByEmpId(String empId);

	public String checkLogin(Employee employee);

}
