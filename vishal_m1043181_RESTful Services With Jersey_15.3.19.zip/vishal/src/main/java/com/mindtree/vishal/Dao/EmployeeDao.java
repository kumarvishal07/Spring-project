package com.mindtree.vishal.Dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import com.mindtree.vishal.Model.Employee;
import org.hibernate.query.Query;

public class EmployeeDao implements DaoImpl {
	private Configuration configuration = new Configuration().configure();
	private SessionFactory sessionFactory;

	@Override
	public Collection<Employee> getAllEmpDetails() {
		System.out.println("getAllEmpDetailsdao");
		Collection<Employee> employeeList = null;

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			Query<Employee> query = session.createQuery("from Employee");
			employeeList = query.list();

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return employeeList;
	}

	@Override
	public Employee addEmp(Employee employee) {
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employee;

	}

	@Override
	public Boolean deleteEmp(String empId) {
		List<Employee> productList = null;
		int x = 0;

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			Query<Employee> query = session.createQuery("delete from Employee where empId = " + empId);
			 
		 x = query.executeUpdate();
			 
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		if (x==1)return true;
		else return false;
	}

	@Override
	public Collection<Employee> getByEmpId(String empId) {
		List<Employee> employeeList = null;

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			Query query = session.createQuery("from Employee where empId = "+ empId);
			employeeList = query.list();

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return employeeList;
	}

	@Override
	public String checkLogin(Employee employee) {
		List<Employee> employeeList = null;

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			Query query = session.createQuery("from Employee");
			employeeList = query.list();
			
			for(Employee emp:employeeList)
			{
				
				if(emp.getUserName().equals(employee.getUserName()))
				{
					if (emp.getPassword().equals(employee.getPassword())) {
						return "User is authenticated Successfully";
					}
					else 
					{
						return "Password is mismatch";
					}
				}
				else {
					return "userName is not Correct";
				}
			}

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		 return "There is some problem with database";
	}

}
