package com.mindtree.vishal.Resourse;

import java.util.Collection;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.digest.DigestUtils;
import org.glassfish.jersey.server.ManagedAsync;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.Futures;

import com.mindtree.vishal.Async.EmployeeDaoAsync;
import com.mindtree.vishal.Dao.DaoImpl;
import com.mindtree.vishal.Dao.EmployeeDao;
import com.mindtree.vishal.Model.Employee;

@Path("/EmpMgt")
public class EmployeeResourse {

	@Context
	EmployeeDaoAsync dao;
	@Context
	Request request;
	EmployeeDao employeeDao = new EmployeeDao();

	@Path("/getAllEmpDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON) // import javax.ws.rs.core.MediaType;
	// @ManagedAsync
	// public Collection<Employee> getAllEmpDetails(@Suspended final AsyncResponse
	// response) {
	public Collection<Employee> getAllEmpDetails() {

		Collection<Employee> employees = (employeeDao.getAllEmpDetails());
		return employees;

		/*
		 * ListenableFuture<Employee> employeeFuture=dao.getAllEmpDetails();
		 * Futures.addCallback(employeeFuture, new FutureCallback<Employee>() { public
		 * void onFailure(Throwable thrown) { response.resume(thrown);
		 * 
		 * }
		 * 
		 * @Override public void onSuccess(Employee employee) {
		 * //response.resume(addedBook); EntityTag
		 * entityTag=generateEntityTag(employee); Response.ResponseBuilder
		 * rb=request.evaluatePreconditions(entityTag); if (rb != null) {
		 * response.resume(rb.build()); } else {
		 * response.resume(Response.ok().tag(entityTag).entity(employee).build()); }
		 * 
		 * } });
		 */

	}

	EntityTag generateEntityTag(Employee employee) {
		return (new EntityTag(DigestUtils.md5Hex(employee.getDateOfBirth() + employee.getEmailID() + employee.getEmpId()
				+ employee.getFullName() + employee.getGender() + employee.getSecurityAnswer()
				+ employee.getSecurityQuestion() + employee.getUserName())) {

		});
	}

	@Path("/addEmp")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Employee addEmp(Employee employee) {
		 
		return employeeDao.addEmp(employee);
	}

	@Path("/deleteEmp/{empId}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public String deleteEmp(@PathParam("empId") String empId) {
		 
		Boolean result = employeeDao.deleteEmp(empId);
		if (result == true)
			return "Employee with id " + empId + " is deleted successfully";
		else
			return "Employee with id " + empId + " is Not found";
	}

	@Path("/getByEmpId/{empId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON) // import javax.ws.rs.core.MediaType;
	public Collection<Employee> getByEmpId(@PathParam("empId") String empId) {
		Collection<Employee> employee = employeeDao.getByEmpId(empId);
		if (employee.isEmpty())
			return null;
		else
			return employee;
	}

	@Path("/checkLogin")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String checkLogin(Employee employee) {

		String userName = employee.getUserName();
		String password = employee.getPassword();

		if (userName == null) {
			return "UserName can not be null..";
		}
		if (password == null) {
			return "Password can not be null..";
		}

		return employeeDao.checkLogin(employee);

	}

}
